package com.frag.muhasebeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.*
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.frag.muhasebeapp.Homepage.HomePage
import com.frag.muhasebeapp.RequestPermission.RequestPermissionsUser
import com.frag.muhasebeapp.TakeAction.TransactionSheet
import com.frag.muhasebeapp.User.User
import com.frag.muhasebeapp.accountHistory.AccountHistoryDetails
import com.frag.muhasebeapp.ui.theme.MuhasebeAppTheme
import com.google.gson.Gson


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val navController = rememberNavController()
            MuhasebeAppTheme {
                Surface(color = MaterialTheme.colors.background) {
                    NavHost(navController = navController , startDestination = "RequestPermissionUser"){
                        composable("RequestPermissionUser") { RequestPermissionsUser(navController , applicationContext , this@MainActivity) }
                        composable("HomePages") { HomePage(navController) }
                        composable("TransactionSheet/{username}/{total_price}" ,
                            arguments = listOf(navArgument("username") { type = NavType.StringType } , navArgument("total_price"){type = NavType.FloatType}),
                        ){
                            TransactionSheet(navController = navController, username = it.arguments!!.getString("username")!! , total_price = it.arguments!!.getFloat("total_price")!!.toDouble() , this@MainActivity )
                        }
                        composable("AccountHistoryDetails/{fileName}/{username}",
                            arguments = listOf(navArgument("fileName"){type = NavType.StringType} , navArgument("username"){type = NavType.StringType})
                        ){ AccountHistoryDetails(navController , fileName = it.arguments!!.getString("fileName")!! , username = it.arguments!!.getString("username")!!) }
                    }
                }
            }
        }
    }
}
