package com.frag.muhasebeapp.User

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("id")
    @Expose
    val id : Int,
    @SerializedName("username")
    @Expose
    val username : String ?="default value",
    @SerializedName("total_price")
    @Expose
    var total_price : Double
)
