package com.frag.muhasebeapp.Homepage

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.frag.muhasebeapp.AlertDialog.ShowDialog
import com.frag.muhasebeapp.JSON.JsonHelper
import com.frag.muhasebeapp.R
import com.frag.muhasebeapp.accountHistory.AccountHistory

@Composable
fun HomePage(navController: NavHostController) {
    val TAG = "HomePage"
    val jsonHelper = JsonHelper()
    val context = LocalContext.current
    val screenSize = LocalConfiguration.current

    var deleteProcess = remember{ mutableStateOf<Boolean>(false)}

    jsonHelper.createFile(context)
    val getUser = jsonHelper.getFileJson(context)

    var showDialogs = remember {
        mutableStateOf(false)
    }

    if(getUser.username == "" && (getUser.total_price == 0.0) && getUser.id == 0){
        ShowDialog(getUser.username!! , getUser.total_price)
    }

    Column {
        Column(modifier = Modifier
            .fillMaxWidth()
            .height(screenSize.screenHeightDp.dp / 3)
            , verticalArrangement = Arrangement.Center , horizontalAlignment = Alignment.CenterHorizontally) {
            Row{

                Button(onClick = { navController.navigate("TransactionSheet/${getUser.username}/${getUser.total_price.toLong()}")},
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Transparent),
                    elevation = ButtonDefaults.elevation(defaultElevation = 0.dp,pressedElevation = 0.dp,disabledElevation = 0.dp)
                ) {
                    Column(verticalArrangement = Arrangement.Center , horizontalAlignment = Alignment.CenterHorizontally) {
                       Image(painterResource(id = R.drawable.ic_baseline_add_24) , contentDescription = "" , modifier = Modifier
                           .clip(RoundedCornerShape(40.dp))
                           .background(Color.Green))
                        Text("İşlem Yap" , fontSize = 10.sp , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                    }
                }

                Column(Modifier.width(screenSize.screenWidthDp.dp / 2) , horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Merhaba!\n${getUser.username}" , textAlign = TextAlign.Center , fontSize = 20.sp , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                    Text("₺${getUser.total_price}" , color = Color.Unspecified , textAlign = TextAlign.Center , fontSize = 20.sp)
                    Divider()
                    TextButton(onClick = { showDialogs.value = true }) {
                        Text("Bilgileri Düzenle" , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , fontSize = 11.sp)
                    }
                }


                Button(onClick = {
                    if(deleteProcess.value) deleteProcess.value = false
                    else deleteProcess.value = true},
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Transparent),
                    elevation = ButtonDefaults.elevation(defaultElevation = 0.dp,
                        pressedElevation = 0.dp,
                        disabledElevation = 0.dp)
                    ) {
                    Column(verticalArrangement = Arrangement.Center , horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(painterResource(id = R.drawable.ic_baseline_remove_24) , contentDescription = "", modifier = Modifier
                            .clip(
                                RoundedCornerShape(40.dp)
                            )
                            .background(Color.Red))
                        Text("İşlem Sil" , fontSize = 10.sp)
                    }
                }
            }
        }


        AccountHistory(navController = navController , getUser.username!! , deleteProcess.value , getUser.total_price)

        if(showDialogs.value){
            ShowDialog(getUser.username!! , getUser.total_price).let {
                showDialogs.value = it
            }
        }
    }
}


