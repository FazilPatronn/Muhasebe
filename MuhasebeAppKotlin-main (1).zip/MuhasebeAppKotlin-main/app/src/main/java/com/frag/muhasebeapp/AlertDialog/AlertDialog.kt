package com.frag.muhasebeapp.AlertDialog

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.AlertDialog
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.sp
import com.frag.muhasebeapp.JSON.JsonHelper
import com.frag.muhasebeapp.R
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter


@Composable
fun ShowDialog(defaultUsername : String , defaultPrice : Double) : Boolean{
    val context = LocalContext.current

    var alertDialogs by remember { mutableStateOf<Boolean>(true)  }
    var closeDialogs by remember { mutableStateOf<Boolean>(true)  }

    //TextFieldValues
    var username by remember { mutableStateOf("")  }
    var price by remember { mutableStateOf<String>("")  }

    //TextFieldErrors
    var usernameError by remember {mutableStateOf(false)}
    var priceError by remember {mutableStateOf(false)}

    if(alertDialogs){
        AlertDialog(
            title = {
                Text("Bilgilerinizi Düzenleyin" , fontFamily = FontFamily(Font(com.frag.muhasebeapp.R.font.signikanegativebold)))
            },
            text = {
                Column {
                    OutlinedTextField(value = username,
                        isError = usernameError,
                        onValueChange = { if(it.length <= 10){
                            username = it
                            usernameError = false
                        }
                        if(it.equals("") && it.length ==0 ){usernameError = true}} , label = {Text("Kullanıcı Adı")})
                    if(usernameError)Text("Kullanıcı Adınız Boş Olamaz !" , color = Color.Red , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , fontSize = 10.sp)



                    OutlinedTextField(value = price,
                        isError = priceError,
                        onValueChange = {
                        if(it.length <=6){
                            price = it
                            priceError = false
                        }
                        if(it.length == 0 && it.equals("")) priceError = true
                        }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number , capitalization = KeyboardCapitalization.Words) , label = {Text("Bakiyeniz")})
                    if (priceError)Text("Bakiye Boş Olamaz !" , color = Color.Red , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , fontSize = 10.sp)
                }
            },
            confirmButton = {
                            TextButton(onClick = {
                                if(!username.equals("") && !price.equals("")) {
                                    JsonHelper().writeJsonFiles(1 , username , price.toDouble() , context)
                                    closeDialogs = false
                                } else if(!username.equals("")){
                                    JsonHelper().writeJsonFiles(1 , username , defaultPrice , context)
                                    closeDialogs = false
                                }else if(!price.equals("")){
                                    JsonHelper().writeJsonFiles(1 , defaultUsername , price.toDouble() , context)
                                    closeDialogs = false
                                }
                            }) {
                                Text("Kaydet")

                            }
            },
            dismissButton = {
                TextButton(onClick = {
                    alertDialogs = false
                    closeDialogs = false

                }) {
                    Text("Kapat")
                }
            },
            onDismissRequest = {
                alertDialogs = false
                closeDialogs = false
            }
        )
    }
    return closeDialogs
}
