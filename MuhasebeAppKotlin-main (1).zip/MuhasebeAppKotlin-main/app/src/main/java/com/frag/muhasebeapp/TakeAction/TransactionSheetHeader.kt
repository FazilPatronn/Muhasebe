package com.frag.muhasebeapp.TakeAction

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.frag.muhasebeapp.R

@Composable
fun TransactionPageHeader(username : String , price : Double){
    Text("Merhaba ! ${username}" , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , textAlign = TextAlign.Center)
    Text("Burada İşlemlerini Yapabilirsin !" , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , textAlign = TextAlign.Center)
    Text("Bakiyen : ${price}" , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , textAlign = TextAlign.Center)
    Divider()
    Spacer(modifier = Modifier.height(10.dp))
}