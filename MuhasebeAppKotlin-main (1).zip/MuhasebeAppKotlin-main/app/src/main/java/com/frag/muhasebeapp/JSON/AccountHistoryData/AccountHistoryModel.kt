package com.frag.muhasebeapp.JSON.AccountHistoryData

data class AccountHistoryModel(
    val date : String,
    val totalPrice : Double,
    val productsNumber : ArrayList<String>,
    val productsName : ArrayList<String>,
    val productsPrice : ArrayList<String>
)