package com.frag.muhasebeapp.TakeAction

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.frag.muhasebeapp.JSON.JsonHelper
import com.frag.muhasebeapp.R
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.io.File


@Composable
fun TransactionSheet(navController: NavHostController , username : String , total_price : Double , context : Context) {
    var transactionName by remember { mutableStateOf("")}
    val productNameList = remember{ mutableStateListOf<String>() }
    var productPriceList = remember{mutableStateListOf<Double>()}
    var productPrice by remember { mutableStateOf("")}
    var price: Double by remember { mutableStateOf<Double>(total_price) }
    var productName by remember { mutableStateOf("")}
    var selectedProductNumbers = remember { mutableStateListOf<String>() }
    var totalProductPrice by remember{ mutableStateOf<Double>(0.0) }
    var visibilityProductsInfo = remember { arrayListOf(false , false , false) }


    var expanded = remember { mutableStateOf(false) }
    val suggestions = listOf("1","2","3","4","5","6","7","8","9","10")
    var selectedText by remember { mutableStateOf("1") }


    val current = LocalDateTime.now()
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm:ss")
    val formatted = current.format(formatter)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        TransactionPageHeader(username , price)
        Column(
            Modifier
                .fillMaxSize()
                .padding(start = 10.dp, end = 10.dp) , horizontalAlignment = Alignment.CenterHorizontally) {
            TextField(value = transactionName, onValueChange = {if(it.length <= 10){
                transactionName = it
                visibilityProductsInfo[0] = true
                if(it.length <= 0) visibilityProductsInfo[0] = false

            }   } , label = {Text("Hesap ismi")} , colors = TextFieldDefaults.textFieldColors(

                cursorColor = Color.Black,
                disabledLabelColor = Color.LightGray,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ) , shape = RoundedCornerShape(10.dp) , modifier = Modifier.fillMaxWidth())


            Spacer(modifier = Modifier.height(10.dp))
            TransactionSheetForm(
                visitProductsInfo = visibilityProductsInfo[0],
                productName = productName,
                productPrice =productPrice ,
                selectedText = selectedText,
                expandedValue = expanded.value ,
                suggestions = suggestions ,
                productNameSend = { productName = it} ,
                productPriceSend = { productPrice = it },
                selectedTextSend ={ selectedText = it } ,
                expandedValueSend = { expanded.value = it } ,
            )

            Spacer(modifier = Modifier.height(10.dp))


            LazyColumn(Modifier.fillMaxWidth()){
                item {
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically , horizontalArrangement = Arrangement.SpaceAround , modifier = Modifier.fillMaxWidth()){
                        Button(onClick = {
                            if((productName.length != 0 && !productName.equals("")) && (productPrice.length != 0 && !productPrice.equals(""))){
                                selectedProductNumbers.add(selectedText)
                                productNameList.add(productName)
                                productPriceList.add(element = productPrice.toDouble() * selectedText.toInt())
                                price = price - (productPrice.toDouble() * selectedText.toInt())

                            }else{System.out.println("Error")}
                        } , colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color.DarkGray,
                        ) , shape = RoundedCornerShape(5.dp))  {
                            Text("Listeye Ekle")
                        }

                        Button(onClick = {
                                         if(transactionName.equals("") && productNameList.isEmpty() && productPriceList.isEmpty()){
                                             Toast.makeText(context ,  "Bilgilerinizi Kontrol Edin Ve Daha Sonra Tekrar Deneyin" , Toast.LENGTH_LONG).show()
                                         }else{
                                             if(price < 0){
                                                 Toast.makeText(context ,  "Hey! bakiyen yetmiyor!" , Toast.LENGTH_LONG).show()
                                             }else{
                                                 val file = File(context.getFilesDir(),"${transactionName}.json")
                                                 if(!file.exists()){
                                                    if((!selectedProductNumbers.isEmpty() && !productNameList.isEmpty() && !productPriceList.isEmpty())){

                                                        productPriceList.forEach {
                                                            totalProductPrice += it
                                                        }
                                                        JsonHelper().writeUserTransactionProcessFile(context , formatted , transactionName , productNameList , productPriceList , selectedProductNumbers , totalProductPrice).let {
                                                            Toast.makeText(context , "Dosya Başarılı bir şekilde kayıt edildi" , Toast.LENGTH_SHORT).show()
                                                        }
                                                        JsonHelper().writeJsonFiles(0 , username , price , context)
                                                        JsonHelper().listCreatedFiles(context , transactionName , formatted)

                                                    }else {
                                                        Toast.makeText(context , "Ürün eklemeden dosyayı kayıt edemezsiniz" , Toast.LENGTH_SHORT).show()
                                                    }
                                                 }else {
                                                     Toast.makeText(context , "Bu dosya ${transactionName} daha önceden oluşturulmuş düzenlemeyi deneyin" , Toast.LENGTH_SHORT).show()
                                                 }
                                             }
                                         }

                        } , colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color.DarkGray,
                        ) , shape = RoundedCornerShape(5.dp) ){
                            Text("Listeyi Kaydet")
                        }
                    }
                }
                item{
                    Row(
                        Modifier
                            .fillMaxSize()
                            .fillMaxHeight() , horizontalArrangement = Arrangement.SpaceAround) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Ürün Adedi" , style = TextStyle(textDecoration = TextDecoration.Underline) , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                            selectedProductNumbers.forEach {
                                Text(it , textAlign = TextAlign.Center)
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Ürün Adı" , style = TextStyle(textDecoration = TextDecoration.Underline) , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                            productNameList.forEach {
                                Text(it , textAlign = TextAlign.Center)
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Ürün Fiyatı" , style = TextStyle(textDecoration = TextDecoration.Underline), fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                            for (i in productPriceList.indices){
                                Text("${productPriceList[i]}")
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Ürünü Sil" , style = TextStyle(textDecoration = TextDecoration.Underline), fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                            for (i in productPriceList.indices){
                                Icon(Icons.Filled.Clear , contentDescription = "" , tint = Color.Red , modifier = Modifier
                                    .width(25.dp)
                                    .height(22.dp)
                                    .clickable {
                                        totalProductPrice -= productPriceList[i]
                                        selectedProductNumbers.removeAt(i)
                                        price += productPriceList[i]
                                        productPriceList.removeAt(i)
                                        productNameList.removeAt(i)
                                    })
                            }
                        }
                    }
                }
            }
        }
    }
}

