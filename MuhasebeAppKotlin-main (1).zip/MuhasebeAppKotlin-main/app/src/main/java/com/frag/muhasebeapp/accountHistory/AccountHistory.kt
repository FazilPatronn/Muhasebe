package com.frag.muhasebeapp.accountHistory

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.Divider
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.frag.muhasebeapp.JSON.JsonHelper
import com.frag.muhasebeapp.R

@Composable
fun AccountHistory(
    navController: NavController,
    username: String,
    visibleIcons: Boolean,
    totalPrice: Double
){
    val context = LocalContext.current
    val interactionSource = remember { MutableInteractionSource() }
    val getHistoryFile = JsonHelper().getCreateAccountHistoryFile(context)


    Column(modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight()) {
        Text("Hesap Geçmişi" ,
            Modifier
                .fillMaxWidth()
                .wrapContentHeight() , textDecoration = TextDecoration.Underline , textAlign = TextAlign.Center , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
        Divider()
        LazyColumn(modifier = Modifier.fillMaxSize()){
            items(getHistoryFile!!) { item ->
                Box(contentAlignment = Alignment.CenterEnd){
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            onClick = {
                                if (!item.fileName.equals("")) navController.navigate("AccountHistoryDetails/${item.fileName}/${username}")
                            }
                        )
                        .padding(10.dp) ,horizontalArrangement = Arrangement.SpaceAround , verticalAlignment = Alignment.CenterVertically ){
                        Text(item.fileName , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , fontSize = 15.sp)
                        Text(item.date , fontFamily = FontFamily(Font(R.font.signikanegativebold)) , fontSize = 15.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedVisibility(visible = visibleIcons, enter = fadeIn() , exit = fadeOut()) {
                            Icon(Icons.Filled.Delete , contentDescription = "" , modifier = Modifier
                                .width(35.dp)
                                .height(35.dp)
                                .padding(end = 10.dp)
                                .clickable(onClick = {
                                    JsonHelper()
                                        .getAccountHistoryDetails(context, item.fileName)
                                        .let {
                                            val totalPrices = totalPrice + it.totalPrice
                                            JsonHelper().writeJsonFiles(
                                                1,
                                                username,
                                                totalPrices,
                                                context
                                            )
                                        }
                                    JsonHelper().deleteItemsInFile(
                                        context,
                                        item.fileName,
                                        item.date
                                    )
                                    Toast
                                        .makeText(
                                            context,
                                            "${item.fileName} İşleminiz silindi işlemde yapılan tutar hesabınıza yatırılacak",
                                            Toast.LENGTH_LONG
                                        )
                                        .show()
                                    JsonHelper().fileDelete(context, item.fileName)
                                    navController.popBackStack()
                                    navController.navigate("HomePages")
                                }))
                        }
                    }
                }
            }
        }
    }
}