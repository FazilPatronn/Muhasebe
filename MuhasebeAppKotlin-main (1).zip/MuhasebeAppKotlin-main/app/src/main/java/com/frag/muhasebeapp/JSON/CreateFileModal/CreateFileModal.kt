package com.frag.muhasebeapp.JSON.CreateFileModal

import com.google.gson.annotations.SerializedName

data class CreateFileModal(
    @SerializedName("fileName")
    val fileName : String,
    @SerializedName("date")
    val date : String
)
