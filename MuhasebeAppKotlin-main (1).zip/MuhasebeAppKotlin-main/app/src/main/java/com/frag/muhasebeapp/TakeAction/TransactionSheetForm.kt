package com.frag.muhasebeapp.TakeAction

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun TransactionSheetForm(
    visitProductsInfo : Boolean,
    productName : String,
    productPrice : String,
    selectedText : String,
    expandedValue : Boolean,
    //Posting Value
    suggestions : List<String>,
    productNameSend : (String) ->Unit,
    productPriceSend : (String) -> Unit,
    selectedTextSend : (String) -> Unit ,
    expandedValueSend : (Boolean) -> Unit,
){
    AnimatedVisibility(visible = visitProductsInfo) {
        Column() {
            TextField(value = productName,
                onValueChange = {
                    productNameSend(it)
                } ,
                label = { Text("Ürün Adı") } ,
                colors = TextFieldDefaults.textFieldColors(
                    cursorColor = Color.Black,
                    disabledLabelColor = Color.LightGray,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ) ,
                shape = RoundedCornerShape(10.dp) ,
                modifier = Modifier
                    .fillMaxWidth())

            Spacer(modifier = Modifier.height(10.dp))

            TextField(value = productPrice ,
                onValueChange = {
                    if(it.length <= 5) productPriceSend(it) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number) ,
                label = { Text("Ürün Fiyatı") },
                colors = TextFieldDefaults.textFieldColors(
                    cursorColor = Color.Black,
                    disabledLabelColor = Color.LightGray,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ) , shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))

            TextField(value = selectedText, textStyle = TextStyle() ,onValueChange = {
                selectedTextSend(it) } , label = { Text("Ürün adedi") }, shape = RoundedCornerShape(10.dp), modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = {
                    expandedValueSend(true)
                }) , enabled = false  ,  colors = TextFieldDefaults.textFieldColors(
                cursorColor = Color.Black,
                disabledLabelColor = Color.LightGray,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            ) , )
            DropdownMenu(
                expanded = expandedValue,
                onDismissRequest = { expandedValueSend(false) },
                modifier = Modifier
                    .background(Color.Black)
            ) {
                suggestions.forEach { label ->
                    DropdownMenuItem(
                        onClick = {
                            selectedTextSend(label)
                            expandedValueSend(false)
                        }) {
                        Text(text = label , textAlign = TextAlign.Center , color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}