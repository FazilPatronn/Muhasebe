package com.frag.muhasebeapp.RequestPermission

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Button
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.core.app.ActivityCompat
import androidx.navigation.NavHostController
import com.frag.muhasebeapp.MainActivity
import com.frag.muhasebeapp.R


@Composable
fun RequestPermissionsUser(
    navController: NavHostController,
    context: Context,
    application: MainActivity
) {

    if(ActivityCompat.shouldShowRequestPermissionRationale(application , Manifest.permission.WRITE_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(application , Manifest.permission.WRITE_EXTERNAL_STORAGE) ){
        Column(Modifier.fillMaxSize() , verticalArrangement = Arrangement.Center , Alignment.CenterHorizontally) {
            Text("Merhaba ! kullanıcı her şeyden önce burada neden geldiğini açıklamama izin ver. \n Buraya gelme sebebin aslında senden istediğimiz izini reddetmen" +
                    "bu izni vermediğin için buradasın ancak uygulamayı kullanmak istiyorsan bu izini vermeni istiyoruz bu izin ${Manifest.permission.WRITE_EXTERNAL_STORAGE} adında bir izindir" +
                    "bu izin senin bu uygulamada yaptığın işlemleri telefonun'da saklamak için isteniyor !. ufak bir araştırma ile anlayabilirsin." +
                    "Şimdi bu izini tekrardan nasıl verebilirim ? diye kendine soruyor olabilirsin hemen endişelenme bu işlem çok kolay ! " +
                    "Telefon ayarlarından 'MuhasebeApp' uygulamasını bul ve izinler sekmesinden gerekli izinleri ver. " +
                    "Daha sonradan tekrar geldiğinde bu sıkıcı sayfayı görmeyeceksin !" , textAlign = TextAlign.Center , fontFamily = FontFamily(
                Font(R.font.signikanegativebold)
            )
            )
            Divider()
            Text("Yada aramak istemiyorsan buradan direk uygulama ayarlarına gidebilirsin" , textAlign = TextAlign.Center , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
            Button(onClick = {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package" , application.packageName , null)
                intent.setData(uri)
                application.startActivity(intent)
            }) {
                Text(text = "Uygulama ayarları")
            }
        }
    }else {
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                application,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                application,
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                200
            ).let {
                navController.popBackStack()
                navController.navigate("HomePages")
            }
        } else {
            navController.popBackStack()
            navController.navigate("HomePages")
        }
    }
}