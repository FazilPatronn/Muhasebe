package com.frag.muhasebeapp.JSON

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateList
import com.frag.muhasebeapp.JSON.AccountHistoryData.AccountHistoryModel
import com.frag.muhasebeapp.JSON.CreateFileModal.CreateFileModal
import com.frag.muhasebeapp.User.User
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.io.*
import java.lang.reflect.Type
import java.security.cert.CertPath

class JsonHelper() {

    private val TAG = "JsonHelper"

    fun createFile(context : Context){
        val file = File(context.getFilesDir(),"Users.json")
        if(!file.exists()){
            val fileWriter = FileWriter(file)
            val bufferedWriter = BufferedWriter(fileWriter)
            bufferedWriter.write(writeJsonFile(0 , "" , 0.0).toString())
            bufferedWriter.close()
            file.createNewFile()
        }else {
            Log.d(TAG, "Dosya zaten oluşturulmuş")
        }
    }

    fun writeUserTransactionProcessFile(context: Context, formatted: String, transactionName: String, productNameList: MutableList<String>, productPriceList: MutableList<Double> , productsNumber : MutableList<String> , totalPrice : Double){
        val file = File(context.getFilesDir(),"${transactionName}.json")
        val fileWriter = FileWriter(file)
        val bufferedWriter = BufferedWriter(fileWriter)
        var jsonListName = arrayListOf<String>()
        var jsonListPrice = arrayListOf<String>()
        var jsonListNumber = arrayListOf<String>()
        for(i in productPriceList.indices){
            jsonListName.add(productNameList[i])
            jsonListPrice.add(productPriceList[i].toString())
            jsonListNumber.add(productsNumber[i])
        }
        val jsons = AccountHistoryModel(formatted ,totalPrice , jsonListNumber ,jsonListName ,jsonListPrice )
        Gson().toJson(jsons).let{
            bufferedWriter.write(it)
        }
        bufferedWriter.close()
    }

    fun listCreatedFiles(context : Context , fileCreateName:String , date : String){
        val file = File(context.filesDir , "createdFiles.json")
        if(!file.exists()){
            val list : ArrayList<CreateFileModal> = arrayListOf()
            list.add(CreateFileModal(fileCreateName , date))
            bufferedWriter(file , list)
        }else{
            val parseJsonList = ArrayList<CreateFileModal>()
            val myType = object : TypeToken<List<CreateFileModal>>() {}.type
            val getJsonList = Gson().fromJson<List<CreateFileModal>>(bufferedReader(file) , myType)
            getJsonList.forEach {
                parseJsonList.add(CreateFileModal(it.fileName , it.date))
            }
            parseJsonList.add(CreateFileModal(fileCreateName , date))
            bufferedWriter(file , parseJsonList)
        }
    }


    fun getAccountHistoryDetails(context : Context , fileName : String) : AccountHistoryModel{
        val file = File(context.filesDir , "${fileName}.json")
        val typeTokens = object : TypeToken<AccountHistoryModel>() {}.type
        val getSelectedFile = Gson().fromJson<AccountHistoryModel>(JsonHelper().bufferedReader(file) , typeTokens)
        return getSelectedFile
    }


    fun getCreateAccountHistoryFile(context : Context): List<CreateFileModal>? {
        val file = File(context.filesDir , "createdFiles.json")
        if(file.exists()){
            val myType = object : TypeToken<List<CreateFileModal>>() {}.type
            var getJsonList = Gson().fromJson<List<CreateFileModal>>(bufferedReader(file) , myType)
            return getJsonList
        }
        return listOf(CreateFileModal("" , ""))
    }

    fun fileDelete(context : Context , fileName : String){
        val file = File(context.filesDir , "${fileName}.json")
        if(file.exists()){
            file.delete()
        }
    }


    fun deleteItemsInFile(context: Context , name : String , date : String){
        val file = File(context.filesDir , "createdFiles.json")
        val myType = object : TypeToken<ArrayList<CreateFileModal>>() {}.type
        var getJsonList = Gson().fromJson<ArrayList<CreateFileModal>>(bufferedReader(file) , myType)
        getJsonList.remove(CreateFileModal(name , date))
        bufferedWriter(file , getJsonList)
    }




    fun getFileJson(context : Context) : User{
        val file = File(context.getFilesDir(),"Users.json")
        val fileReader = FileReader(file)
        val bufferReader = BufferedReader(fileReader)
        var line = bufferReader.readLine()
        val tpyeToken = object : TypeToken<User?>(){}.type
        val users = Gson().fromJson<User>(line , tpyeToken)
        while(line != null){line = bufferReader.readLine()}
        bufferReader.close()
        return users
    }


    private fun writeJsonFile(userId : Int, username : String, total_price : Double) : JSONObject {
        val jsonObject = JSONObject()
        jsonObject.put("id" , userId)
        jsonObject.put("username" , username)
        jsonObject.put("total_price" , total_price)
        return jsonObject
    }
    fun writeJsonFiles(userId : Int, username : String, total_price : Double , context: Context)  {
        val file = File(context.filesDir , "Users.json")
        val fileWriter = FileWriter(file)
        val bufferedWriter = BufferedWriter(fileWriter)
        val jsonWriter = JSONObject()
        jsonWriter.put("id" , userId)
        jsonWriter.put("username" , username)
        jsonWriter.put("total_price" , total_price)
        bufferedWriter.write(jsonWriter.toString())
        bufferedWriter.close()
    }


    fun bufferedReader(file : File) : String{
        val fileReader = FileReader(file)
        val bufferedReader = BufferedReader(fileReader)
        var line = bufferedReader.readLine()
        bufferedReader.close()
        return line
    }

    private fun bufferedWriter(file : File , list : ArrayList<CreateFileModal>){
        val fileWriter = FileWriter(file)
        val bufferedWriter = BufferedWriter(fileWriter)
        Gson().toJson(list).let {
            bufferedWriter.write(it)
        }
        bufferedWriter.close()
    }
}