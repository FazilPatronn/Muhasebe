package com.frag.muhasebeapp.accountHistory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.frag.muhasebeapp.JSON.AccountHistoryData.AccountHistoryModel
import com.frag.muhasebeapp.JSON.JsonHelper
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import com.frag.muhasebeapp.R

@Composable
fun AccountHistoryDetails(navController: NavController , fileName : String , username : String){
    val context = LocalContext.current
    val getAccountHistory = JsonHelper().getAccountHistoryDetails(context , fileName = fileName)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Hey ! ${username}" , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
        Text("Burada daha önceden yaptığın hesapları görebilirsin !" , fontFamily = FontFamily(Font(R.font.signikanegativebold)))

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()){
            item {
                Row(modifier = Modifier.fillMaxWidth() , horizontalArrangement = Arrangement.SpaceAround , verticalAlignment = Alignment.CenterVertically){
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ürün Adetleri" , textAlign = TextAlign.Center)
                        getAccountHistory.productsNumber.forEach {
                            Text(it , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ürün İsimleri" , textAlign = TextAlign.Center)
                        getAccountHistory.productsName.forEach {
                            Text(it , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ürün Fiyatları" , textAlign = TextAlign.Center)
                        getAccountHistory.productsPrice.forEach {
                            Text(it , fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Column(modifier = Modifier.fillMaxWidth() , verticalArrangement = Arrangement.Center , horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("İşlem Tutarı : ${getAccountHistory.totalPrice}", fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                    Text("İşlem Tarihi : ${getAccountHistory.date}", fontFamily = FontFamily(Font(R.font.signikanegativebold)))
                }
            }
        }
    }
}